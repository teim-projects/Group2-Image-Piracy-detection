import React, { useState } from "react";
import "./PlagiarismSearch.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Image } from "react-bootstrap";
import image from "./BG-Image.png";

const PlagiarismSearch = () => {
  const [selectedImages, setSelectedImages] = useState([]);
  const [image, setImage] = useState({ preview: '', data: '' })
  const [status, setStatus] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    let formData = new FormData()
    formData.append('file', image.data)
	console.log("Ererererere");
    const response = fetch('http://localhost:5000/image', {
      method: 'POST',
      body: formData,
    }).then(response => response.json())
	.then((body) => {
		setStatus("OK")
		 console.log(body);
	});  
    //if (response) {
	//	setStatus(response.statusText)
	//	console.log(response.json())
	//	//console.log(response.json())
	//	console.log(response.statusText)
	//}
  }

  const onSelectFile = (event) => {
    const selectedFiles = event.target.files;
    const selectedFilesArray = Array.from(selectedFiles);

    const imagesArray = selectedFilesArray.map((file) => {
      return URL.createObjectURL(file);
    });

    setSelectedImages((previousImages) => previousImages.concat(imagesArray));

    event.target.value = "";
	if(selectedFilesArray.length !== 0){
		const img = {
			preview: URL.createObjectURL(selectedFilesArray[0]),
			data: selectedFilesArray[0],
		  }
		  setImage(img)
	  }
	
  };

  function deleteHandler(image) {
    setSelectedImages(selectedImages.filter((e) => e !== image));
    URL.revokeObjectURL(image);
  }

  return (
    <section>
      <div style={{ backgroundImage:`url(${image})`,backgroundSize:"contain", height:712 }}>

      <label>
         <p class="box-text">Add Image</p>
        <br />
        <input
          type="file"
          name="images"
          onChange={onSelectFile}
          multiple
          accept="image/png , image/jpeg, image/webp"
        />
      </label>
      <br />


      <input type="file" multiple />

      {selectedImages.length > 0 &&
        (selectedImages.length > 1 ? (
          <p className="error">
            You can't upload more than 1 images! <br />
            <span>
              please delete <b> {selectedImages.length - 1} </b> of them{" "}
            </span>
          </p>
        ) : (
          <button
            className="upload-btn"
            onClick={(e) => {
              console.log(selectedImages);
			  handleSubmit(e);
            }}
          >
            Search
            <img class="search-icon" src={require("./search.png")}/>
            {selectedImages.length === 1 ? "" : "S"}
          </button>
        ))}

      <div className="images">
        {selectedImages &&
          selectedImages.map((image, index) => {
            return (
              <div  key={image} className="image">
                <img class="ImageDisplay" src={image} height="200" alt="upload" />
                <button class = "delete-btn" onClick={() => deleteHandler(image)}>
                  <img class="trash" src={require("./trash.png")}/>
                </button>
              </div>
            );
          })}
      </div>
      </div>

    </section>
  );
};

export default PlagiarismSearch;
